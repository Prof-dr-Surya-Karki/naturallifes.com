const scriptURL = 'https://script.google.com/macros/s/AKfycbzZIWg8AS35_QSLmrO9-bJD5r4FDIgYzGp-GQOvHeyKgCARMbzztQn64cwZSYgNQROTSA/exec'
const Registration_Form = document.forms['registration-form']

fetch(scriptURL, {
    method: 'POST',
    body: new FormData(Registration_Form)
  })
  .then(() => {
    console.log('success')
    registrationSuccess()
  })
  .catch((error) => {
    console.error('Error!', error.message)
  })